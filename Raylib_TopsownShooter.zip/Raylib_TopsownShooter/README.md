# TopDownShooter Web Build

This project is a **Top Down Shooter** built with **raylib** and compiled for the web using **Emscripten**.

# Comp with web

## Setup Emscripten Environment
cd C:\Users\bora2\emsdk
.\emsdk_env.ps1

## Navigate to the raylib source directory:

cd C:\raylib\raylib\src

## Compile each module with Emscripten:

emcc -c rcore.c -Os -Wall -DPLATFORM_WEB -DGRAPHICS_API_OPENGL_ES2

emcc -c rshapes.c -Os -Wall -DPLATFORM_WEB -DGRAPHICS_API_OPENGL_ES2

emcc -c rtextures.c -Os -Wall -DPLATFORM_WEB -DGRAPHICS_API_OPENGL_ES2

emcc -c rtext.c -Os -Wall -DPLATFORM_WEB -DGRAPHICS_API_OPENGL_ES2

emcc -c rmodels.c -Os -Wall -DPLATFORM_WEB -DGRAPHICS_API_OPENGL_ES2

emcc -c utils.c -Os -Wall -DPLATFORM_WEB

emcc -c raudio.c -Os -Wall -DPLATFORM_WEB

### Create a static library:

emar rcs libraylib.a rcore.o rshapes.o rtextures.o rtext.o rmodels.o utils.o raudio.o


emmake make PLATFORM=PLATFORM_WEB -B

## Compile Your Game

### Navigate to your game project folder:
cd "C:\Users\bora2\OneDrive\Desktop\GameDev Projects\Raylib_TopsownShooter"
 
 ### Compile the game with Emscripten:
 
 em++ main.cpp -o index.html -I C:/raylib/raylib/src -L C:/raylib/raylib/src/web -lraylib -s USE_GLFW=3 -s ASYNCIFY

## This will generate:

index.html

index.js

index.wasm

You can now open index.html in a browser to play your game.

## itch link

https://bora0dev.itch.io/wavebreaker

## Gif

![WaveBreaker Demo](demo.gif)