#include "raylib.h"
#include <vector>
#include <cmath>
#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#endif

// ---------------- Player ----------------
class Player {
public:
    Vector2 position;
    int health;
    float speed;
    float radius;
    const int maxHealth = 100;

    Player() {
        position = {500.f, 500.f};
        health = maxHealth;
        speed = 300.f;
        radius = 20.f;
    }

    void ResetHealth() { health = maxHealth; }
    void ResetPosition() { position = {500.f, 500.f}; }

    void Update(float delta) {
        if (IsKeyDown(KEY_W)) position.y -= speed * delta;
        if (IsKeyDown(KEY_S)) position.y += speed * delta;
        if (IsKeyDown(KEY_A)) position.x -= speed * delta;
        if (IsKeyDown(KEY_D)) position.x += speed * delta;

        if (position.x < radius) position.x = radius;
        if (position.x > GetScreenWidth() - radius) position.x = GetScreenWidth() - radius;
        if (position.y < radius) position.y = radius;
        if (position.y > GetScreenHeight() - radius) position.y = GetScreenHeight() - radius;
    }

    void Draw() { DrawCircleV(position, radius, GREEN); }
};

// ---------------- Gun ----------------
class Gun {
public:
    float distanceFromPlayer = 40.f;
    float size = 20.f;

    Vector2 GetPosition(Vector2 playerPos) {
        Vector2 mouse = GetMousePosition();
        float angle = atan2f(mouse.y - playerPos.y, mouse.x - playerPos.x);
        return {playerPos.x + cosf(angle) * distanceFromPlayer,
                playerPos.y + sinf(angle) * distanceFromPlayer};
    }

    void Draw(Vector2 playerPos) { DrawCircleV(GetPosition(playerPos), size, DARKGRAY); }
};

// ---------------- Bullet ----------------
class Bullet {
public:
    Vector2 position;
    Vector2 velocity;
    float radius;
    int damage;

    Bullet(Vector2 start, Vector2 target) {
        position = start;
        float angle = atan2f(target.y - start.y, target.x - start.x);
        float speed = 500.f;
        velocity = {cosf(angle) * speed, sinf(angle) * speed};
        radius = 5.f;
        damage = 20;
    }

    void Update(float delta) {
        position.x += velocity.x * delta;
        position.y += velocity.y * delta;
    }

    void Draw() { DrawCircleV(position, radius, YELLOW); }

    bool IsOffScreen() {
        return position.x < 0.f || position.x > GetScreenWidth() ||
               position.y < 0.f || position.y > GetScreenHeight();
    }
};

// ---------------- Enemy ----------------
class Enemy {
public:
    Vector2 position;
    int health;
    float speed;
    float radius;

    Enemy(Vector2 spawnPos, int hp, float spd) {
        position = spawnPos;
        health = hp;
        speed = spd;
        radius = 15.f;
    }

    void Update(float delta, Vector2 playerPos) {
        Vector2 dir = {playerPos.x - position.x, playerPos.y - position.y};
        float len = sqrtf(dir.x * dir.x + dir.y * dir.y);
        if (len > 0.f) { dir.x /= len; dir.y /= len; }
        position.x += dir.x * speed * delta;
        position.y += dir.y * speed * delta;
    }

    void Draw() { DrawCircleV(position, radius, RED); }
};

// ---------------- Game States ----------------
enum class GameState {
    MENU,
    PLAYING,
    PAUSED,
    GAME_OVER
};

// ---------------- Main ----------------
int main() {
    InitWindow(1000, 1000, "WaveBreaker");
    SetTargetFPS(60);

    Player player;
    Gun gun;
    std::vector<Enemy> enemies;
    std::vector<Bullet> bullets;

    int currentWave = 1;
    int enemiesRemaining = 0;
    bool gameOver = false;

    GameState state = GameState::MENU;

    // Spawn wave
    auto SpawnWave = [&](int wave) {
        enemies.clear();
        bullets.clear();
        player.ResetHealth();
        player.ResetPosition();

        int count = static_cast<int>(5 * pow(1.2f, wave - 1));
        int hp = 30 + wave * 5;
        float spd = 60.f * pow(1.1f, wave - 1.f);

        for (int i = 0; i < count; i++) {
            Vector2 spawn = {static_cast<float>(GetRandomValue(0, 1000)),
                             static_cast<float>(GetRandomValue(0, 1000))};
            enemies.push_back(Enemy(spawn, hp, spd));
        }
        enemiesRemaining = count;
    };

#ifdef __EMSCRIPTEN__
    auto main_loop = [&]() {
#endif

    while (!WindowShouldClose()) {
        float delta = GetFrameTime();
        Vector2 mouse = GetMousePosition();

        // ------------- MENU -------------
        if (state == GameState::MENU) {
            Rectangle playBtn = {
                static_cast<float>(GetScreenWidth()/2 - 100),
                static_cast<float>(GetScreenHeight()/2 - 60),
                200.0f,
                60.0f
            };
            Rectangle quitBtn = {
                static_cast<float>(GetScreenWidth()/2 - 100),
                static_cast<float>(GetScreenHeight()/2 + 20),
                200.0f,
                60.0f
            };

            BeginDrawing();
            ClearBackground(BLACK);
            DrawText("WaveBreaker", GetScreenWidth()/2 - 160, 200, 40, YELLOW);

            DrawRectangleRec(playBtn, DARKGRAY);
            DrawText("PLAY", playBtn.x + 65, playBtn.y + 15, 30, WHITE);

            DrawRectangleRec(quitBtn, DARKGRAY);
            DrawText("QUIT", quitBtn.x + 65, quitBtn.y + 15, 30, WHITE);

            if (CheckCollisionPointRec(mouse, playBtn) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                currentWave = 1;
                SpawnWave(currentWave);
                gameOver = false;
                state = GameState::PLAYING;
            }
            if (CheckCollisionPointRec(mouse, quitBtn) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                CloseWindow();
                return 0;
            }

            EndDrawing();
            continue;
        }

        // ------------- PAUSED -------------
        if (state == GameState::PAUSED) {
            if (IsKeyPressed(KEY_ESCAPE)) state = GameState::PLAYING;

            Rectangle resumeBtn = {
                static_cast<float>(GetScreenWidth()/2 - 100),
                static_cast<float>(GetScreenHeight()/2 - 100),
                200.0f,
                60.0f
            };
            Rectangle restartBtn = {
                static_cast<float>(GetScreenWidth()/2 - 100),
                static_cast<float>(GetScreenHeight()/2 - 20),
                200.0f,
                60.0f
            };
            Rectangle quitBtn = {
                static_cast<float>(GetScreenWidth()/2 - 100),
                static_cast<float>(GetScreenHeight()/2 + 60),
                200.0f,
                60.0f
            };

            BeginDrawing();
            ClearBackground(BLACK);
            DrawText("PAUSED", GetScreenWidth()/2 - 80, 150, 40, YELLOW);

            DrawRectangleRec(resumeBtn, DARKGRAY);
            DrawText("RESUME", resumeBtn.x + 35, resumeBtn.y + 15, 30, WHITE);

            DrawRectangleRec(restartBtn, DARKGRAY);
            DrawText("RESTART", restartBtn.x + 30, restartBtn.y + 15, 30, WHITE);

            DrawRectangleRec(quitBtn, DARKGRAY);
            DrawText("QUIT", quitBtn.x + 65, quitBtn.y + 15, 30, WHITE);

            if (CheckCollisionPointRec(mouse, resumeBtn) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON))
                state = GameState::PLAYING;
            if (CheckCollisionPointRec(mouse, restartBtn) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                currentWave = 1;
                SpawnWave(currentWave);
                gameOver = false;
                state = GameState::PLAYING;
            }
            if (CheckCollisionPointRec(mouse, quitBtn) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                state = GameState::MENU;
            }

            EndDrawing();
            continue;
        }

        // ------------- PLAYING -------------
        if (state == GameState::PLAYING) {
            if (IsKeyPressed(KEY_ESCAPE)) {
                state = GameState::PAUSED;
                continue;
            }

            player.Update(delta);

            // Shoot bullets
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                bullets.push_back(Bullet(gun.GetPosition(player.position), GetMousePosition()));
            }

            // Update bullets
            for (int i = 0; i < (int)bullets.size(); i++) {
                bullets[i].Update(delta);
                if (bullets[i].IsOffScreen()) {
                    bullets.erase(bullets.begin() + i);
                    i--;
                }
            }

            // Update enemies
            for (int i = 0; i < (int)enemies.size(); i++) {
                enemies[i].Update(delta, player.position);

                if (CheckCollisionCircles(player.position, player.radius,
                                          enemies[i].position, enemies[i].radius)) {
                    player.health -= 10;
                    enemies.erase(enemies.begin() + i);
                    enemiesRemaining--;
                    i--;
                    if (player.health <= 0) { gameOver = true; state = GameState::GAME_OVER; }
                    continue;
                }

                for (int j = 0; j < (int)bullets.size(); j++) {
                    if (CheckCollisionCircles(bullets[j].position, bullets[j].radius,
                                              enemies[i].position, enemies[i].radius)) {
                        enemies[i].health -= bullets[j].damage;
                        bullets.erase(bullets.begin() + j);
                        j--;
                        if (enemies[i].health <= 0) {
                            enemies.erase(enemies.begin() + i);
                            enemiesRemaining--;
                            i--;
                        }
                        break;
                    }
                }
            }

            if (enemiesRemaining <= 0 && !gameOver) {
                currentWave++;
                SpawnWave(currentWave);
            }

            // Draw
            BeginDrawing();
            ClearBackground(BLACK);
            player.Draw();
            gun.Draw(player.position);
            for (auto &enemy : enemies) enemy.Draw();
            for (auto &bullet : bullets) bullet.Draw();

            DrawText(TextFormat("Health: %d", player.health), 20, 20, 20, WHITE);
            DrawText(TextFormat("Wave: %d", currentWave), 20, 50, 20, WHITE);
            DrawCircleLines(mouse.x, mouse.y, 10.f, YELLOW);
            EndDrawing();
            continue;
        }

        // ------------- GAME OVER -------------
        if (state == GameState::GAME_OVER) {
            BeginDrawing();
            ClearBackground(BLACK);

            const char *msg = TextFormat("Game Over! You survived %d rounds!", currentWave);
            int msgWidth = MeasureText(msg, 30);
            DrawText(msg, GetScreenWidth()/2 - msgWidth/2, GetScreenHeight()/2 - 120, 30, RED);

            Rectangle replayBtn = {
                static_cast<float>(GetScreenWidth()/2 - 110),
                static_cast<float>(GetScreenHeight()/2),
                100.0f,
                60.0f
            };
            Rectangle menuBtn = {
                static_cast<float>(GetScreenWidth()/2 + 10),
                static_cast<float>(GetScreenHeight()/2),
                100.0f,
                60.0f
            };

            DrawRectangleRec(replayBtn, DARKGRAY);
            DrawText("REPLAY", replayBtn.x + 10, replayBtn.y + 20, 20, WHITE);

            DrawRectangleRec(menuBtn, DARKGRAY);
            DrawText("MENU", menuBtn.x + 25, menuBtn.y + 20, 20, WHITE);

            if (CheckCollisionPointRec(mouse, replayBtn) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                currentWave = 1;
                SpawnWave(currentWave);
                gameOver = false;
                state = GameState::PLAYING;
            }

            if (CheckCollisionPointRec(mouse, menuBtn) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                state = GameState::MENU;
            }

            EndDrawing();
            continue;
        }
    }

#ifdef __EMSCRIPTEN__
    };
    emscripten_set_main_loop_arg([](void* arg){ (*reinterpret_cast<decltype(main_loop)*>(arg))(); }, &main_loop, 0, 1);
#endif

    CloseWindow();
    return 0;
}
